<!DOCTYPE html>
<html>
<head>
    <title>Edit a Student</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    {{-- <style>
        body {
            display:inline-block;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            text-align: center;
        }
        .form-container {
            display:inline-block;
            text-align: center;
         
            align-items: center;
            margin-top: 50px;
        }
        .form-header {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }
        .form-header h2 {
            margin: auto;
        }
        .form-content {
            width: 50%;
        }
        .form row{
            table-layout: auto
        }
        
        .btn {
            padding: 10px 20px;
            text-decoration: none;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            border: none;
        }
        .btn-primary:hover {
            background-color: #86aef7;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
            border: none;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
    </style> --}}
</head>
<body>
    <div style="max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;text-align:center;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="margin: 0;color: #4CAF50;">Edit Student</h2>
        </div>
        <div>
            <a href="{{ route('student.index') }}" style="text-decoration: none; color: #fff; background-color: #007bff; padding: 10px 20px; border-radius: 5px;">Back</a>
        </div>
    </div>

    @if ($errors->any())
    <div style="background-color: #f8d7da; color: #721c24; padding: 10px; border: 1px solid #f5c6cb; border-radius: 5px; margin-bottom: 20px;">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul style="margin: 0; padding-left: 20px;">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
    @endif
</div>
    <form method="post"action="{{ route('student.update',['student'=>$student])}}">
        @csrf
         @method('put')
         <div style="display: flex; flex-direction: column; gap: 15px;">
            <div style="display: flex; flex-direction: column;">
                <label for="name" style="margin-bottom: 5px;">Name</label>
                <input type="text" id="name" name="name" placeholder="Name" value="{{ $student->name }}" style="padding: 10px;width:30%; border: 1px solid #0b0a0a; border-radius: 5px;"/>
            </div>

            <div style="display: flex; flex-direction: column;">
                <label for="email" style="margin-bottom: 5px;">Email</label>
                <input type="email" id="email" name="email" placeholder="Email" value="{{ $student->email }}" style="padding: 10px;width:30%; border: 1px solid #0e0d0d; border-radius: 5px;"/>
            </div>
        
        
            <div style="display: flex; flex-direction: column;">
                <label for="dob" style="margin-bottom: 5px;">DOB</label>
                <input type="date" id="dob" name="dob" placeholder="DOB" value="{{ $student->dob }}" style="padding: 10px;width:30%; border: 1px solid #080808; border-radius: 5px;"/>
            </div>

            <div style="display: flex; flex-direction: column;">
                <label for="address" style="margin-bottom: 5px;">Address</label>
                <input type="text" id="address" name="address" placeholder="Address" value="{{ $student->address }}" style="padding: 10px; width:30%;border: 1px solid #141414; border-radius: 5px;"/>
            </div>

             
            <div style="display: flex; flex-direction: column;">
                <label for="image" style="margin-bottom: 5px;">Image</label>
                <input type="file" id="image" name="image" placeholder="Profile Picture" style="padding: 10px;width:30%; border: 1px solid #1c1919; border-radius: 5px;"/>
            </div>

            
            <div style="text-align: center;">
                <button type="submit" class="btn btn-primary" style="background-color: #007bff; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Update</button>
            </div>
        </div>

     </form>
    </div>
</body>
</html>
