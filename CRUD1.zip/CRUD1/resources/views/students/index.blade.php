<!DOCTYPE html>
<html>
<head>
    <title> CRUD - Students</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
  
</head>
<body>
    <h1 style="text-align: center; color: #4CAF50;">Students</h1>
<div>
    @if(session()->has('success'))
<div>
    {{session('success')}}
</div>
        
    @endif
</div>
<div style="margin: 20px;">
    <div style="margin-bottom: 15px;">
        <a href="{{ route('student.create') }}" style="text-decoration: none; color: #fff; background-color: #5cb85c; padding: 10px 20px; border-radius: 5px;">Create Student</a>
    </div>
    <table border="2" style="width: 100%; border-collapse: collapse;">
        <tr style="background-color: #f2f2f2;">
            <th style="padding: 10px;">ID</th>
            <th style="padding: 10px;">Name</th>
            <th style="padding: 10px;">Email</th>
            <th style="padding: 10px;">Dob</th>
            <th style="padding: 10px;">Address</th>
            <th style="padding: 10px;">Edit</th>
            <th style="padding: 10px;">Delete</th>
            <th style="padding: 10px;">Upload Image</th>
            
        </tr>
        @php
        $id = 0; // Initialize the $id variable
    @endphp
        @foreach($students as $student)
        <tr>
            <td style="padding: 10px; text-align: center;">{{ ++$id }}</td>
            <td style="padding: 10px; text-align: center;">{{ $student->name }}</td>
            <td style="padding: 10px; text-align: center;">{{ $student->email }}</td>
            <td style="padding: 10px; text-align: center;">{{ $student->dob }}</td>
            <td style="padding: 10px; text-align: center;">{{ $student->address }}</td>
            <td style="padding: 10px; text-align: center;">  
                <a class="btn btn-secondary" href="{{ route('student.edit',['student' =>$student])}}"style="text-decoration: none; color: #fff; background-color: #5bc0de; padding: 5px 10px; border-radius: 5px;">Edit</a>
            </td>
            <td style="padding: 10px; text-align: center;">
                <form method="POST" action="{{ route('student.destroy', ['student' => $student]) }}">
                    @csrf
                    @method('delete')
                
                    <input type="submit" value="Delete" class="btn-delete"style="background-color: #d9534f; color: #fff; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;"/>
                </form>
            </td>
            <td>
                @if($student->image)
                    <img src="{{ asset('public/uploads/image.png' . $student->image) }}" alt="Student Image" width="100">
                @else
                    No Image
                @endif
            </td>
        </tr>
        @endforeach
    </table>
</div>
</body>
</html>
