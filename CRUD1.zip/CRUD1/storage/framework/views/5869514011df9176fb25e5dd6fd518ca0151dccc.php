<!DOCTYPE html>
<html>
<head>
    <title>Edit a Student</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
</head>
<body>
    <div style="max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;text-align:center;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="margin: 0;color: #4CAF50;">Edit Student</h2>
        </div>
        <div>
            <a href="<?php echo e(route('student.index')); ?>" style="text-decoration: none; color: #fff; background-color: #007bff; padding: 10px 20px; border-radius: 5px;">Back</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
    <div style="background-color: #f8d7da; color: #721c24; padding: 10px; border: 1px solid #f5c6cb; border-radius: 5px; margin-bottom: 20px;">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul style="margin: 0; padding-left: 20px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    <?php endif; ?>
</div>
    <form method="post"action="<?php echo e(route('student.update',['student'=>$student])); ?>">
        <?php echo csrf_field(); ?>
         <?php echo method_field('put'); ?>
         <div style="display: flex; flex-direction: column; gap: 15px;">
            <div style="display: flex; flex-direction: column;">
                <label for="name" style="margin-bottom: 5px;">Name</label>
                <input type="text" id="name" name="name" placeholder="Name" value="<?php echo e($student->name); ?>" style="padding: 10px;width:30%; border: 1px solid #0b0a0a; border-radius: 5px;"/>
            </div>

            <div style="display: flex; flex-direction: column;">
                <label for="email" style="margin-bottom: 5px;">Email</label>
                <input type="email" id="email" name="email" placeholder="Email" value="<?php echo e($student->email); ?>" style="padding: 10px;width:30%; border: 1px solid #0e0d0d; border-radius: 5px;"/>
            </div>
        
        
            <div style="display: flex; flex-direction: column;">
                <label for="dob" style="margin-bottom: 5px;">DOB</label>
                <input type="date" id="dob" name="dob" placeholder="DOB" value="<?php echo e($student->dob); ?>" style="padding: 10px;width:30%; border: 1px solid #080808; border-radius: 5px;"/>
            </div>

            <div style="display: flex; flex-direction: column;">
                <label for="address" style="margin-bottom: 5px;">Address</label>
                <input type="text" id="address" name="address" placeholder="Address" value="<?php echo e($student->address); ?>" style="padding: 10px; width:30%;border: 1px solid #141414; border-radius: 5px;"/>
            </div>

             
            <div style="display: flex; flex-direction: column;">
                <label for="image" style="margin-bottom: 5px;">Image</label>
                <input type="file" id="image" name="image" placeholder="Profile Picture" style="padding: 10px;width:30%; border: 1px solid #1c1919; border-radius: 5px;"/>
            </div>

            
            <div style="text-align: center;">
                <button type="submit" class="btn btn-primary" style="background-color: #007bff; color: #fff; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Update</button>
            </div>
        </div>

     </form>
    </div>
</body>
</html>
<?php /**PATH C:\xamp\htdocs\CRUD1\resources\views/students/edit.blade.php ENDPATH**/ ?>