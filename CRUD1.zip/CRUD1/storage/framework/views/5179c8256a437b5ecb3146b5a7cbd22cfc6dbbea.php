<!DOCTYPE html>
<html>
<head>
    <title> CRUD - Students</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
  
</head>
<body>
    <h1 style="text-align: center; color: #4CAF50;">Students</h1>
<div>
    <?php if(session()->has('success')): ?>
<div>
    <?php echo e(session('success')); ?>

</div>
        
    <?php endif; ?>
</div>
<div style="margin: 20px;">
    <div style="margin-bottom: 15px;">
        <a href="<?php echo e(route('student.create')); ?>" style="text-decoration: none; color: #fff; background-color: #5cb85c; padding: 10px 20px; border-radius: 5px;">Create Student</a>
    </div>
    <table border="2" style="width: 100%; border-collapse: collapse;">
        <tr style="background-color: #f2f2f2;">
            <th style="padding: 10px;">ID</th>
            <th style="padding: 10px;">Name</th>
            <th style="padding: 10px;">Email</th>
            <th style="padding: 10px;">Dob</th>
            <th style="padding: 10px;">Address</th>
            <th style="padding: 10px;">Edit</th>
            <th style="padding: 10px;">Delete</th>
            <th style="padding: 10px;">Upload Image</th>
            
        </tr>
        <?php
        $id = 0; // Initialize the $id variable
    ?>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="padding: 10px; text-align: center;"><?php echo e(++$id); ?></td>
            <td style="padding: 10px; text-align: center;"><?php echo e($student->name); ?></td>
            <td style="padding: 10px; text-align: center;"><?php echo e($student->email); ?></td>
            <td style="padding: 10px; text-align: center;"><?php echo e($student->dob); ?></td>
            <td style="padding: 10px; text-align: center;"><?php echo e($student->address); ?></td>
            <td style="padding: 10px; text-align: center;">  
                <a class="btn btn-secondary" href="<?php echo e(route('student.edit',['student' =>$student])); ?>"style="text-decoration: none; color: #fff; background-color: #5bc0de; padding: 5px 10px; border-radius: 5px;">Edit</a>
            </td>
            <td style="padding: 10px; text-align: center;">
                <form method="POST" action="<?php echo e(route('student.destroy', ['student' => $student])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                
                    <input type="submit" value="Delete" class="btn-delete"style="background-color: #d9534f; color: #fff; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;"/>
                </form>
            </td>
            <td>
                <?php if($student->image): ?>
                    <img src="<?php echo e(asset('public/uploads/image.png' . $student->image)); ?>" alt="Student Image" width="100">
                <?php else: ?>
                    No Image
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</body>
</html>
<?php /**PATH C:\xamp\htdocs\CRUD1\resources\views/students/index.blade.php ENDPATH**/ ?>