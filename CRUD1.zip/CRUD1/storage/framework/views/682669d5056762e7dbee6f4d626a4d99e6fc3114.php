<!DOCTYPE html>
<html>
<head>
    <title>Add Students Info</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <linl rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  
</head>

<body>
    <h2 style="margin: 0; text-align:center;padding:10px;color: #4CAF50;">Add Student</h2>
    <div class="form-container">
        <?php if($errors->any()): ?>
        <div style="background-color: #f8d7da; color: #4b6616; padding: 10px; border: 1px solid #f5c6cb; border-radius: 5px; margin-bottom: 20px;">
        <ul style="margin: 0; padding-left: 20px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </div>
    <form method="post"action="<?php echo e(route('student.store')); ?>">
       <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <div class="form-group">
                    <label for="name" style="margin-bottom: 5px;">Name</label>
                    <input type="name" name="name"placeholder="Name"style="width: 20%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <div class="form-group">
                <label>Email</label>
                    <input type="email" name="email" placeholder="Email"style="width: 20%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <div class="form-group">
                <label>DOB</label>
                    <input type="date" name="dob" placeholder="DOB"style="width: 20%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <div class="form-group">
                 <label>Address</label>
                    <input type="text" name="address" placeholder="Address"style="width: 20%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <div class="form-group">
                 <label>Image</label>
                    <input type="file" name="image" placeholder="Profile Picture"style="width: 20%; padding: 10px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

    </form>
    </div>
    
</body>
</html>
<?php /**PATH C:\xamp\htdocs\CRUD1\resources\views/students/create.blade.php ENDPATH**/ ?>