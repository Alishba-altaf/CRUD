<!DOCTYPE html>
<html>
<head>
    <title>Edit a Student</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Student</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('students.index')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    <?php endif; ?>
</div>
    <<form method="post"action="<?php echo e(route('student.update',['student'=>$student])); ?>">
        <?php echo csrf_field(); ?>
         <?php echo method_field('put'); ?>
         <div class="row">
             <div class="col-xs-12 col-sm-12 col-md-12">
                 <div class="form-group">
                     <label>Name</label>
                     <input type="name" name="name"placeholder="Name" value="<?php echo e($student->name); ?>"/>
                 </div>
             </div>
             <div class="col-xs-12 col-sm-12 col-md-12">
                 <div class="form-group">
                 <label>Email</label>
                     <input type="email" name="email" placeholder="Email"value="<?php echo e($student->email); ?>"/>
                 </div>
             </div>
             <div class="col-xs-12 col-sm-12 col-md-12">
                 <div class="form-group">
                 <label>DOB</label>
                     <input type="date" name="dob" placeholder="DOB"value="<?php echo e($student->dob); ?>"/>
                 </div>
             </div>
             <div class="col-xs-12 col-sm-12 col-md-12">
                 <div class="form-group">
                  <label>Address</label>
                     <input type="text" name="text" placeholder="Address"value="<?php echo e($student->address); ?>"/>
                 </div>
             </div>
             <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                 <button type="submit" class="btn btn-primary">Update</button>
             </div>
         </div>
 
     </form>
</body>
</html>
<?php /**PATH C:\xamp\htdocs\CRUD1\resources\views/students\edit.blade.php ENDPATH**/ ?>