<?php
namespace App\Http\Controllers;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Student;



class StudentController extends Controller
{
    public function index()
    {
        $students = Student::all();
        return view ('students.index')->with('students', $students);
      
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('students.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request): RedirectResponse
    {
      // dd($request);
       $data = $request->validate([
        'name'=> 'required',
        'email' => 'required|email:rfc',
        'dob'=> 'required',
        'address'=> 'required',
       // 'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048', // Validate image file
       ]);
        // // Handle image upload
        // if ($request->hasFile('image')) {
        //   $image = $request->file('image');
        //   $imageName = time() . '_' . $image->getClientOriginalName();
        //   $image->move(public_path('uploads'), $imageName); // Move image to public/uploads directory



      $newStudent = Student::create($data);
      return redirect(route('student.index'));
    }
  

 

    public function edit(Student $student)
     {
        
        return view('students.edit',['student'=>$student]);
     }

     public function update(Student $student, Request $request)
   {
        $data = $request->validate([
             'name' => 'required',
             'email' => 'required|email|unique:students,email,' . $student->id,
             'dob' => 'required',
             'address'=> 'required',
         ]);

        $student->update($data);
        return redirect(route('student.index'))->with('success', 'Student updated successfully.');
   }

   public function destroy(Student $student)
       {
          $student->delete();
            return redirect()->route('student.index')->with('success', 'Student deleted successfully.');
       }

}


//     public function show(): view
//     {
//         return view('students.show', compact('student'));
//     }

    


